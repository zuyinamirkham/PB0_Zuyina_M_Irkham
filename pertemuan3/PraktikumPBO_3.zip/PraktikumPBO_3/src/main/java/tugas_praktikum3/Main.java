/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum3;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Mitsubhisi", "Canter", 2014, "kuning");
        mobil1.displayInfo();
        mobil1.startEngine();
        
        Mobil mobil2 = new Mobil("Toyota", "Rangga",2025, "putih");
        mobil2.displayInfo();
        mobil2.startEngine();
    }
}
