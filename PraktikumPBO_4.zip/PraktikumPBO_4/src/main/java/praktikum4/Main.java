/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        pekerja pekerja1 = new pekerja("hanif", 45, "Back End", 90000000);


        System.out.println("=== Informasi Pekerja Awal ===");
        System.out.println(pekerja1.toString());

        pekerja1.setNama("hanif raharjo");
        System.out.println("\n=== Setelah Nama Diubah ===");
        System.out.println(pekerja1.toString());
        
        System.out.println(pekerja1.nama);      
        System.out.println(pekerja1.usia);      
        System.out.println(pekerja1.pekerjaan); 
        System.out.println(pekerja1.gaji);
        
    }
}
