/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package praktikum4;

/**
 *
 * @author acer
 */
public class PraktikumPBO_4 {

    public static void main(String[] args) {
        // 1. Membuat objek dari class turunan (Mobil)
        mobil mobil1 = new mobil("L300", 120, "Bensin", 2);

        System.out.println("=== Data Awal ===");
        
        // 2. Memanggil metode dari class induk (Kendaraan)
        mobil1.tampilkanInfoKendaraan();
        
        System.out.println("-----------------");
        
        // 3. Memanggil metode spesifik dari class turunan (Mobil)
        mobil1.tampilkanInfoMobil();

        System.out.println("\n=== Setelah Perubahan ===");
        
        // 4. Mengubah nama (private) menggunakan setter dari class induk
        mobil1.setNama("L300 Euro 4");
        
        // 5. Mengubah jenis mesin (public) secara langsung (tanpa setter)
        mobil1.jenisMesin = "Diesel";
        
        // Menampilkan kembali data setelah diubah
        mobil1.tampilkanInfoKendaraan();
    }
}
