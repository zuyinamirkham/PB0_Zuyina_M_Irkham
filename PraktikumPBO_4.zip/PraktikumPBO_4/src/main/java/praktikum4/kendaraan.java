/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class kendaraan {
    //Atribut dengan akses modifier berbeda
    private String nama;          //hanya bisa diakses dalam kelas ini
    protected int kecepatanMaks;  //bisa diakses dipackage yang sama dan subclass
    public String jenisMesin;    //bisa diakses dari mana aja
    
    // Constructor
    public kendaraan(String nama,  int kecepatanMaks, String jenisMesin) {
        this.nama = nama;
        this.kecepatanMaks = kecepatanMaks;
        this.jenisMesin = jenisMesin;
    }
    // Getter dan Setter untuk variabel private nama
    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    //method public untuk menampilkan informasi kendaraan
    public void tampilkanInfoKendaraan() {
        System.out.println("Nama kendaraan: " + nama);
        System.out.println("Kecepatan maksimum: " + kecepatanMaks + "Km/h");
        System.out.println("Jenis mesin: " + jenisMesin);
    }
}
