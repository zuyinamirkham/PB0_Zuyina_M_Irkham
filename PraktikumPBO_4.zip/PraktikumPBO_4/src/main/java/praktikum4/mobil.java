/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class mobil extends kendaraan {
    private int jumlahPintu; //atribut tambahan khusus untuk mobil
    
    //constructor
    public mobil(String nama, int kecepatanMaks, String jenisMesin, int jumlahPintu) {
        super(nama, kecepatanMaks, jenisMesin);
        this.jumlahPintu = jumlahPintu;
    }
        
    //methods untuk menampilkan informasi mobil
    public void tampilkanInfoMobil() {
        //dapat mengakses kecepatan karena protected
        System.out.println("Kecepatan maksimum mobil: " + kecepatanMaks + "Km/h");
        System.out.println("Jumlah pintu: " + jumlahPintu);
    }
    
}
